# Empolyee Management System

<!-- gif not showing due to large size
<p align="center">
  <img src="https://github.com/deepakjaiswal2018/Empolyee-Management-System/demo.gif" alt="Demo" width="850" />
</p>
-->
<!-- A Project which easily handle employee data with mysql database by performing CRUD Operation. -->

```
CLASS Creation Steps:
1.conn
2.welcome_page
3.login_page
4.details_page
5.add_employee
6.view_employee
7.print_data
8.remove_employee
9.search_employee
10.update_employee
```
